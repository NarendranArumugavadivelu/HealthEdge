package com.cooper.farming;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CooperFarmingApplicationTests {

	@Test
	void contextLoads() {
	}

}
